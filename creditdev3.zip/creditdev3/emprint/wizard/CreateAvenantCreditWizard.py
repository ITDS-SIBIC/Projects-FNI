# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError


class CreateAvenantCreditWizard(models.TransientModel):
    _name = 'create.avenant.credit.wizard'  # Updated name to reflect credit
    _description = u'Création Avenant'

    convention_id = fields.Many2one('credit.convention', string='Convention initial',
                                    readonly=True)  # Updated to credit.convention
    partner_id = fields.Many2one(related='convention_id.partner_id', string='Client')
    date_avenant = fields.Date('Date', required=True)  # Added required validation
    objet = fields.Char('Objet', required=True)  # Added required validation
    user_id = fields.Many2one('res.users', string='Responsable', default=lambda self: self.env.user)

    def action_appliquer(self):
        """Create a new amendment from the existing credit convention."""
        # Check if the convention is in a state that allows modification
        if self.convention_id.state not in ['validee', 'done']:
            raise UserError(_('La convention doit être validée ou en brouillon pour créer un avenant.'))

        # Duplicate the convention to create a new amendment
        avenant = self.convention_id.copy()



        # Reset the fields for the new amendment
        self.convention_id.write({})

        # Modify fields of the new amendment
        avenant.objet_avenant = self.objet  # Update the subject of the amendment
        avenant.user_id = self.user_id.id
        avenant.date = self.date_avenant
        avenant.type_convention = 'avenant'  # Specify the type as 'avenant'
        avenant.state = 'draft'  # Set the state of the new amendment to 'draft'

        # Handle amendment numbering
        if self.convention_id.num_avenantcn:
            avenant.num_avenantcn = str(int(self.convention_id.num_avenantcn) + 1)
        else:
            avenant.num_avenantcn = '1'

        # Update the name of the amendment with the new number
        avenant.name += '/' + avenant.num_avenantcn

        return {
            'name': _(u'Nouvel Avenant'),
            'type': 'ir.actions.act_window',
            'res_model': 'credit.convention',  # Updated to reflect the credit.convention model
            'view_mode': 'form',
            'view_id': self.env.ref('emprint.credit_convention_form_view').id,  # Update with your module name
            'target': 'current',
            'res_id': avenant.id,
        }
