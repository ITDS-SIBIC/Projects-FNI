from odoo import models, fields, api, _
from odoo.exceptions import UserError

class AvenantConventionCreditWizard(models.TransientModel):
    _name = 'avenant.convention.credit.wizard'  # Updated class name
    _description = 'Wizard to update credit convention fields'

    convention_id = fields.Many2one('creditconvention', string='Convention', required=True)  # Reference to the credit convention model
    objet = fields.Char(string='Objet du crédit', required=True)
    commission_gestion = fields.Float(string='Commission de Gestion', required=True)
    taux_interet = fields.Float(string='Taux d\'Intérêt', required=True)
    penalite = fields.Float(string='Pénalité', required=True)
    montant = fields.Float(string='Montant', required=True)
    # Add more fields as necessary...

    def action_update_convention(self):
        """Update the convention record with the wizard's values."""
        self.ensure_one()
        if self.convention_id.state != 'validee':  # Ensure the convention is validated before updates
            raise UserError(_('La convention doit être validée pour effectuer des modifications.'))

        self.convention_id.write({
            'objet': self.objet,
            'commission_gestion': self.commission_gestion,
            'taux_interet': self.taux_interet,
            'penalite': self.penalite,
            'montant': self.montant,
            # Update other fields as necessary
        })
        return {'type': 'ir.actions.act_window_close'}

    def action_avenant(self):
        """Open the avenant wizard to create a new avenant for the credit convention."""
        self.ensure_one()  # Ensure this method is called on a single record
        if self.convention_id.state != 'validee':  # Check if the convention is validated
            raise UserError(_('Vous ne pouvez pas créer un avenant tant que la convention n\'est pas validée.'))

        return {
            'name': _('Créer Avenant'),
            'type': 'ir.actions.act_window',
            'res_model': 'avenantcredit',  # Updated model reference for the credit amendment
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_convention_id': self.convention_id.id,  # Pass the convention ID to the new avenant
                'default_objet_avenant': self.objet,  # Pass default values to the wizard
                'default_montant': self.montant,
                # Add any other necessary fields...
            },
        }
