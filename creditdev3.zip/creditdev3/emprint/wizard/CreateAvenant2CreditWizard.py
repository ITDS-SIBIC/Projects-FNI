from odoo import api, fields, models, _
from odoo.exceptions import UserError


class CreateAvenant2CreditWizard(models.TransientModel):  # Added '2' to class name
    _name = 'create.avenant2.credit.wizard'  # Added '2' to model name
    _description = 'Enregistrement'

    convention_id = fields.Many2one('credit.convention', string='Convention initial', readonly=True)  # Updated model reference
    partner_id = fields.Many2one(related='convention_id.partner_id', string='Client')
    date_enregistrement = fields.Date('Date', required=True)  # Added required validation
    objet = fields.Char('Objet', required=True)  # Added required validation
    user_id = fields.Many2one('res.users', string='Responsable', default=lambda self: self.env.user)
    num_enregistrement = fields.Char('Numéro d\'enregistrement', required=True)  # Added required validation

    def action_appliquer(self):
        """Update the convention with the new information and return the action to open it."""
        if not self.convention_id:
            raise UserError(_('Veuillez sélectionner une convention.'))  # Error if convention is not set

        # Update the convention record with new information
        self.convention_id.write({
            'objet': self.objet,
            'date_enregistrement': self.date_enregistrement,
            'num_enregistrement': self.num_enregistrement,
            # Include any additional fields that need updating
        })

        return {
            'name': _(u'Nouvel avenant'),
            'type': 'ir.actions.act_window',
            'res_model': 'credit.convention',  # Updated model reference
            'view_mode': 'form',
            'view_id': self.env.ref('engagement.convention_form_view').id,  # Ensure this view exists
            'target': 'current',
            'res_id': self.convention_id.id,
        }
