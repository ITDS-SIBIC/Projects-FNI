from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import timedelta


class CreditConvention(models.Model):
    _name = 'credit.convention'  # Change the model name
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = u'Convention de Crédit'  # Updated description

    @api.onchange('commission_gestion')
    def _onchange_commission_gestion(self):
        if self.commission_gestion:
            self.commission_gestion *= 0.01

    @api.onchange('taux_interet')
    def _onchange_taux_interet(self):
        if self.taux_interet:
            self.taux_interet *= 0.01

    @api.onchange('penalite')
    def _onchange_penalite(self):
        if self.penalite:
            self.penalite *= 0.01
    @api.depends('taux_interet', 'commission_gestion')
    def _compute_taux_commission_intercalaire(self):
        for record in self:
            record.taux_commission_intercalaire = record.taux_interet + record.commission_gestion
    def action_convert_values(self):
        """Méthode pour convertir les valeurs par 0.10."""
        for record in self:
            record.commission_gestion *= 0.10
            record.taux_interet *= 0.10
            record.penalite *= 0.10

        # Optionnel : Message de confirmation
        return {
            'effect': {
                'fadeout': 'slow',
                'message': 'Les valeurs ont été converties avec succès !',
                'type': 'rainbow_man',
            }
        }
    @api.depends('duree_annee')
    def _duree_mois(self):
        for rec in self:
            rec.duree_mois = rec.duree_annee * 12

    @api.depends('duree_utilisation', 'date_premiere_mobilisation')
    def _compute_date_limite_utilisation(self):
        for record in self:
            if record.duree_utilisation and record.date_premiere_mobilisation:
                duree = timedelta(days=record.duree_utilisation * 365)
                record.date_limite_utilisation = record.date_premiere_mobilisation + duree
            else:
                record.date_limite_utilisation = False

    # Fields definition
    name = fields.Char(u'Numéro', required=True, readonly=True, default='New')
    objet = fields.Char(u'Objet du crédit', tracking=True, required=True)
    num_accord = fields.Char('Accord du comité des engagements')
    num_avenantcn = fields.Char(u'Numéro avenant', default=0)
    user_id = fields.Many2one('res.users', string='Responsable', default=lambda self: self.env.user)
    num_enregistrement = fields.Char('Numéro enregistrement')
    date_enregistrement = fields.Date('Date d\'enregistrement')
    date_signature = fields.Date('Date signature', default=fields.Date.today())
    date_notification = fields.Date('Date notification')
    date_limite = fields.Date('Date limite')
    type_credit = fields.Selection([('investissement', 'Investissement')], string=u'Type crédit', default='investissement')
    partner_id = fields.Many2one('res.partner', string='Client', required=True)

    state = fields.Selection([
        ('draft', 'En saisie'),
        ('in_progress', 'Vérifié'),
        ('done', 'Validé'),
        ('closed', 'Clôturé'),
        ('archived', 'Archivé'),
    ], default='draft', string="State")

    description = fields.Text('Description')
    commission_gestion = fields.Float('Commission de Gestion', required=True)
    taux_interet = fields.Float('Taux d\'Intérêt', required=True)
    penalite = fields.Float('Pénalité', required=True)

    montant = fields.Float(string='Montant')
    taux_commission_intercalaire = fields.Float('Taux Commission Intercalaire',
                                                compute='_compute_taux_commission_intercalaire', store=True)

    @api.depends('taux_interet', 'commission_gestion')
    def _compute_taux_commission_intercalaire(self):
        for record in self:
            record.taux_commission_intercalaire = record.taux_interet + record.commission_gestion

    commission_gestion_10 = fields.Float('Commission de Gestion (10%)', compute='_compute_commission_gestion_10')

    currency_id = fields.Many2one('res.currency', string='Devise', default=lambda self: self.env.company.currency_id)

    duree_annee = fields.Integer('Durée (année)', required=True)
    duree_mois = fields.Integer(compute='_compute_duree_mois', string='Durée (mois)')

    date_premiere_mobilisation = fields.Date('Date première mobilisation')
    date_limite_utilisation = fields.Date('Date limite d\'utilisation', compute='_compute_date_limite_utilisation', store=True)

    # Avenant fields
    type_convention = fields.Selection([('convention', 'Convention'), ('avenant', 'Avenant')], string='Type', default='convention')
    parent_id = fields.Many2one('credit.convention', string='Convention origine', readonly=True)  # Updated reference
    objet_avenant = fields.Char(u'Objet de l\'avenant', tracking=True)
    date = fields.Date('Date')
    avenant_ids = fields.One2many('credit.convention', 'parent_id', string='Avenants')  # Updated reference

    # DPP fields
    dpp1 = fields.Selection([('PM', 'PM'), ('cni', 'CNI'), ('cim', 'CIM'), ('cpe', 'CPE'), ('autre', 'Autre')], string='Décision pouvoir publique 01')
    ref_DPP1 = fields.Char('Référence DPP1')
    ref_dpp1_date = fields.Date('Date')

    dpp2 = fields.Selection([('pm', 'PM'), ('cni', 'CNI'), ('cim', 'CIM'), ('cpe', 'CPE'), ('autre', 'Autre')], string='Décision pouvoir publique 02')
    ref_DPP2 = fields.Char('Référence DPP2')
    ref_dpp2_date = fields.Date('Date')

    dpp3 = fields.Selection([('pm', 'PM'), ('cni', 'CNI'), ('cim', 'CIM'), ('cpe', 'CPE'), ('autre', 'Autre')], string='Décision pouvoir publique 03')
    ref_DPP3 = fields.Char('Référence DPP3')
    ref_dpp3_date = fields.Date('Date')

    dpp4 = fields.Selection([('pm', 'PM'), ('cni', 'CNI'), ('cim', 'CIM'), ('cpe', 'CPE'), ('autre', 'Autre')], string='Décision pouvoir publique 04')
    ref_DPP4 = fields.Char('Référence DPP4')
    ref_dpp4_date = fields.Date('Date')

    # Tutelle fields
    dt1 = fields.Selection([('PM', 'PM'), ('cni', 'CNI'), ('cim', 'CIM'), ('cpe', 'CPE'), ('autre', 'Autre')], string='Décision Tutelle 01')
    dt1_date = fields.Date('Date Décision Tutelle 01')

    dt2 = fields.Selection([('PM', 'PM'), ('cni', 'CNI'), ('cim', 'CIM'), ('cpe', 'CPE'), ('autre', 'Autre')], string='Décision Tutelle 02')
    dt2_date = fields.Date('Date Décision Tutelle 02')

    dt3 = fields.Selection([('PM', 'PM'), ('cni', 'CNI'), ('cim', 'CIM'), ('cpe', 'CPE'), ('autre', 'Autre')], string='Décision Tutelle 03')
    dt3_date = fields.Date('Date Décision Tutelle 03')

    dt4 = fields.Selection([('PM', 'PM'), ('cni', 'CNI'), ('cim', 'CIM'), ('cpe', 'CPE'), ('autre', 'Autre')], string='Décision Tutelle 04')
    dt4_date = fields.Date('Date Décision Tutelle 04')

    # Other fields for various states
    nantissement_action = fields.Char('Nantissement d\'action ')
    nantissement_action_date = fields.Date('Date de nantissement d\'action')
    fichier_piece_jointe_nantissement_action = fields.Binary(string='Nantissement d\'action Pièce Jointe')
    nantissement_action_piece = fields.Char(string='Nom du Fichier')
    checkbox_field_action = fields.Boolean(string='Cocher si oui')

    nantissement_equipement = fields.Char('Nantissement d\'équipement ')
    nantissement_equipement_date = fields.Date('Date d\'enregistrement de publication')
    fichier_piece_jointe_nantissement_equipement = fields.Binary(string='Nantissement d\'équipement Pièce Jointe')
    nantissement_equipement_piece = fields.Char(string='Nom du Fichier')
    checkbox_field_equipement = fields.Boolean(string='Cocher si oui')

    specimen_signature = fields.Char('Spécimen de signature')
    specimen_signature_date = fields.Date('Date de spécimen de signature')
    fichier_piece_jointe_specimen_signature = fields.Binary(string='Specimen de signature Pièce Jointe')
    specimen_signature_piece = fields.Char(string='Nom du Fichier')
    checkbox_field_specimen = fields.Boolean(string='Cocher si oui')

    billet_ordre_global = fields.Char('Billet à ordre global')
    billet_ordre_global_date = fields.Date('Date de Billet à ordre global')
    fichier_piece_jointe_billet_ordre_global = fields.Binary(string='Billet à ordre global Pièce Jointe')
    billet_ordre_global_piece = fields.Char(string='Nom du Fichier')
    checkbox_field_billet = fields.Boolean(string='Cocher si oui')

    chaine_billet_ordre = fields.Char('Chaine de billet à ordre après la période d\'utilisation')
    chaine_billet_ordre_date = fields.Date('Date de chaine de billet à ordre après la période d\'utilisation')
    fichier_piece_jointe_chaine_billet_ordre = fields.Binary(string='chaine de billet à ordre global Pièce Jointe')
    chaine_billet_ordre_piece = fields.Char(string='Nom du Fichier')
    checkbox_field_chaine = fields.Boolean(string='Cocher si oui')

    caution_solidaire = fields.Char('Caution solidaire')
    caution_solidaire_date = fields.Date('Date de caution solidaire')
    fichier_piece_jointe_caution_solidaire = fields.Binary(string='caution solidaire Pièce Jointe')
    caution_solidaire_piece = fields.Char(string='Nom du Fichier')
    checkbox_field_caution = fields.Boolean(string='Cocher si oui')

    garantie_fianciere = fields.Selection([('fgar', 'FGAR'), ('cgci', 'CGCI')], string='Garantie financière')
    garantie_fianciere_date = fields.Date('Date de garantie financière')
    fichier_piece_jointe_garantie_fianciere = fields.Binary(string='Garantie financière Pièce Jointe')
    garantie_fianciere_piece = fields.Char(string='Nom du Fichier')
    checkbox_field_garantie_fianciere = fields.Boolean(string='Cocher si oui')

    assurance = fields.Char('Autre / Assurance et subrogation d\'assurance')
    assurance_date = fields.Date('Date d\'Assurance et subrogation d\'assurance / Autre')
    fichier_piece_jointe_assurance = fields.Binary(string='Autre / Assurance et subrogation d\'assurance Pièce Jointe')
    assurance_piece = fields.Char(string='Nom du Fichier')
    checkbox_field_assurance = fields.Boolean(string='Cocher si oui')

    # Method to compute duration in months
    @api.depends('duree_annee', 'duree_mois')
    def _compute_duree_mois(self):
        for record in self:
            record.duree_mois = record.duree_annee * 12

    # Method to compute usage limit date
    @api.depends('date_signature', 'duree_annee')
    def _compute_date_limite_utilisation(self):
        for record in self:
            if record.date_signature:
                record.date_limite_utilisation = record.date_signature + timedelta(days=(record.duree_annee * 365))

    # Method to compute management commission 10%
    @api.depends('commission_gestion')
    def _compute_commission_gestion_10(self):
        for record in self:
            record.commission_gestion_10 = record.commission_gestion * 0.10

    # Method to compute intermediary commission rate
    @api.depends('montant', 'commission_gestion_10')
    def _compute_taux_commission_intercalaire(self):
        for record in self:
            if record.montant:
                record.taux_commission_intercalaire = (record.commission_gestion_10 / record.montant) * 100
            else:
                record.taux_commission_intercalaire = 0.0

    # Method to create sequence number for convention
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('credit.convention.sequence') or 'New'  # Updated sequence
        return super(CreditConvention, self).create(vals)

    # Method to manage states
    def action_verifier(self):
        self.write({'state': 'in_progress'})

    def action_valider(self):
        self.write({'state': 'done'})

    def action_close(self):
        self.write({'state': 'closed'})


    def action_reset_to_draft(self):
        self.write({'state': 'draft'})

    def create_avenantc(self, objet_avenant='Nouvel avenant', montant=0.0):
       return {
        'name': _(u'Création avenant'),
        'type': 'ir.actions.act_window',
        'res_model': 'create.avenant.credit.wizard',  # Utiliser le bon modèle
        'view_mode': 'form',
        'view_id': self.env.ref('emprint.create_avenant_credit_form').id,  # Utiliser le bon ID de vue
        'target': 'new',
        'context': {
            'default_convention_id': self.id,
            'default_date_avenant': fields.Date.today(),
            'avenant_vals': {
                'objet_avenant': objet_avenant,
                'montant': montant,
            }
        }
    }
