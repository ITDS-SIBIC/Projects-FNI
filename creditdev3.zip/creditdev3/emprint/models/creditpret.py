from odoo import models, fields, api, _
from odoo.exceptions import UserError

class CreditPret(models.Model):
    _name = 'creditdev3.credit_pret'  # Updated name to credit_pret
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = u'Prêt'

    @api.depends('duree_annee')
    def _duree_mois(self):
        for rec in self:
            rec.duree_mois = rec.duree_annee * 12

    name = fields.Char(string='Name')

    objet_contrat = fields.Char(u'Objet du prêt', tracking=True, required=True)
    date = fields.Date('Date signature')
    commission_gestion = fields.Monetary('Commission de Gestion', currency_field='currency_id')
    taux_interet = fields.Float('Taux d\'Intérêt')
    penalite = fields.Float('Pénalité')
    montant = fields.Float(string='Montant')

    duree_credit = fields.Integer(string="Durée de Crédit (mois)")
    date_limite = fields.Date(string="Date Limite")
    duree_differee_mois = fields.Integer(string="Durée Différée (mois)")
    taux_interets_intercalaires = fields.Float(string="Taux Intérêts Intercalaires")

    partner_id = fields.Many2one('res.partner', string='Client', required=False)
    conv_id = fields.Many2one('convention', string='Convention', required=True)

    user_id = fields.Many2one('res.users', string='Responsable', default=lambda self: self.env.user)
    state = fields.Selection([
        ('draft', 'En saisie'),
        ('in_progress', 'Vérifié'),
        ('done', 'Validé'),
        ('closed', 'Clôturé'),
    ], default='draft', string="State")

    description = fields.Text('Description')
    co_contractants = fields.Char('Co-contractants')

    montant_dz = fields.Monetary('Montant')
    com = fields.Char(string='COM')
    currency_id = fields.Many2one('res.currency', string='Devise', default=lambda self: self.env.company.currency_id)

    rebrique_ids = fields.Many2many('rebrique', string='Rubriques')
    total_montant_da = fields.Float(string='Total Montant DA', compute='_compute_total_montant_da', store=True)

    @api.depends('rebrique_ids.montant_da')
    def _compute_total_montant_da(self):
        for record in self:
            record.total_montant_da = sum(record.rebrique_ids.mapped('montant_da'))
            if record.total_montant_da > record.conv_id.montant:
                raise UserError(
                    _('Vous ne pouvez pas ajouter d\'autres rubriques car la somme des Montant DA dépasse le montant de la convention.'))

    @api.constrains('rebrique_ids')
    def _check_rebrique_montant(self):
        for record in self:
            total_montant_da = sum(record.rebrique_ids.mapped('montant_da'))
            if total_montant_da > record.conv_id.montant:
                raise UserError(_('La somme des Montant DA des rubriques ne doit pas dépasser le montant de la convention.'))

    # Documents
    nom_doc_cnt = fields.Char('Nom de document')
    fichier_piece_jointe_doc_cnt = fields.Binary(string='Document Pièce Jointe')
    doc_cnt_piece = fields.Char(string='Nom du Fichier')

    # Avenant
    type_contrat = fields.Selection([('pret', 'Pret'), ('avenant', 'Avenant')], string='Type', default='pret')
    num_avenant = fields.Char('Numéro avenant', readonly=True)

    objet_avenant = fields.Char(u'Objet de l\'avenant', tracking=True)

    # Décisions
    dpp1 = fields.Selection([
        ('PM', 'PM'),
        ('cni', 'CNI'),
        ('cim', 'CIM'),
        ('cpe', 'CPE'),
        ('autre', 'Autre')
    ], string='Décision pouvoir publique 01')
    ref_DPP1 = fields.Char('Référence DPP1')
    ref_dpp1_date = fields.Date('Date DPP1')

    dpp2 = fields.Selection([
        ('PM', 'PM'),
        ('cni', 'CNI'),
        ('cim', 'CIM'),
        ('cpe', 'CPE'),
        ('autre', 'Autre')
    ], string='Décision pouvoir publique 02')
    ref_DPP2 = fields.Char('Référence DPP2')
    ref_dpp2_date = fields.Date('Date DPP2')

    dpp3 = fields.Selection([
        ('PM', 'PM'),
        ('cni', 'CNI'),
        ('cim', 'CIM'),
        ('cpe', 'CPE'),
        ('autre', 'Autre')
    ], string='Décision pouvoir publique 03')
    ref_DPP3 = fields.Char('Référence DPP3')
    ref_dpp3_date = fields.Date('Date DPP3')

    dpp4 = fields.Selection([
        ('PM', 'PM'),
        ('cni', 'CNI'),
        ('cim', 'CIM'),
        ('cpe', 'CPE'),
        ('autre', 'Autre')
    ], string='Décision pouvoir publique 04')
    ref_DPP4 = fields.Char('Référence DPP4')
    ref_dpp4_date = fields.Date('Date DPP4')

    # Champs pour Décision Tutelle
    dt1 = fields.Selection([
        ('PM', 'PM'),
        ('cni', 'CNI'),
        ('cim', 'CIM'),
        ('cpe', 'CPE'),
        ('autre', 'Autre')
    ], string='Décision Tutelle 01')
    ref_DT1 = fields.Char('Référence DT1')
    ref_dt1_date = fields.Date('Date DT1')

    dt2 = fields.Selection([
        ('PM', 'PM'),
        ('cni', 'CNI'),
        ('cim', 'CIM'),
        ('cpe', 'CPE'),
        ('autre', 'Autre')
    ], string='Décision Tutelle 02')
    ref_DT2 = fields.Char('Référence DT2')
    ref_dt2_date = fields.Date('Date DT2')

    dt3 = fields.Selection([
        ('PM', 'PM'),
        ('cni', 'CNI'),
        ('cim', 'CIM'),
        ('cpe', 'CPE'),
        ('autre', 'Autre')
    ], string='Décision Tutelle 03')
    ref_DT3 = fields.Char('Référence DT3')
    ref_dt3_date = fields.Date('Date DT3')

    dt4 = fields.Selection([
        ('PM', 'PM'),
        ('cni', 'CNI'),
        ('cim', 'CIM'),
        ('cpe', 'CPE'),
        ('autre', 'Autre')
    ], string='Décision Tutelle 04')
    ref_DT4 = fields.Char('Référence DT4')
    ref_dt4_date = fields.Date('Date DT4')

    # Nouveaux Champs
    source_financement = fields.Selection([
        ('resources_fni', 'Resources FNI'),
        ('trésor', 'Sur resources du trésor'),
        ('bailleur_etranger', 'Bailleur de fond étranger')
    ], string='Source de Financement')

    objet_financement = fields.Selection([
        ('pret_investissement', 'Prêt d\'Investissement'),
        ('participation_capital', 'Participation au capital social'),
        ('credit_exploitation', 'Crédit d\'Exploitation'),
        ('financement_refinancement', 'Financement d\'Investissement Refinancement')
    ], string='Objet de Financement')

    secteur_activite = fields.Selection([
        ('Hydrolique', 'Hydrolique'),
        ('industrie mechanique', 'industrie mechanique'),
        ('energie', 'energie'),
    ], string='Secteur d\'Activité')

    wilaya = fields.Char(string='Wilaya')
    periode_remb_interets = fields.Date(string="Période de remboursement des intérêts intercalaires")
    periode_remb_principal = fields.Date(string="Période de remboursement du principal")
    dates_fixes_remb_interets = fields.Date(string="Dates fixes de remboursement des intérêts intercalaires")

    service_gestionnaire = fields.Selection([
        ('credit_DR_alger', 'Département Crédit - DR Alger'),
        ('direction_gestion_financement', 'Direction Gestion des Financements pour Compte'),
        ('departement_financement_compte', 'Département Financement pour Compte'),
        ('direction_regionale_alger', 'Direction Régionale d\'Alger'),
        ('direction_regionale_annaba', 'Direction Régionale Annaba'),
        ('direction_regionale_constantine', 'Direction Régionale Constantine'),
        ('direction_regionale_oran', 'Direction Régionale d\'Oran'),
        ('service_gestion_1', 'Service Gestion 1'),
        ('service_gestion_2', 'Service de Gestion 02'),
        ('service_credit_dr_alger', 'Service Crédit DR Alger')
    ], string='Service Gestionnaire')

    assurance = fields.Char(string='Assurance')
    montant_assurance = fields.Float(string='Montant Assurance')
    date_signature = fields.Date(string='Date de signature')
    date_reception = fields.Date(string='Date de réception')

    # Méthodes
    def action_verifier(self):
        self.write({'state': 'in_progress'})

    def action_valider(self):
        self.write({'state': 'done'})

    def action_cloturer(self):
        self.write({'state': 'closed'})

    # Avenant Related Methods
