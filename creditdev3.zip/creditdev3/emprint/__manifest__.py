# -*- coding: utf-8 -*-
{
    'name': 'devcredit',
    'version': '17.0',
    'author': ' ITDS',
    'category': 'Service',
    'license': 'LGPL-3',
    'sequence': 1,
    'website': 'site',
    'description': """
    """,

    'depends': ['base', 'mail', ],
    'images' : ['static/description/icon.png', ],
    'data': [
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'views/creditconvention.xml',

        'views/client.xml',
        'wizard/CreateAvenantCreditWizard.xml',
        'wizard/CreateAvenant2CreditWizard.xml',


        'views/menu.xml',
    ],
    'demo': [],
    'test': [],

    'installable': True,

    'application': True,
    'auto_install': True,
}
