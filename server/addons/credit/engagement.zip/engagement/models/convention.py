from odoo import models, fields, api, _
from odoo.exceptions import UserError



class Convention(models.Model):
    _name = 'convention'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = u'Convention'

    @api.depends('duree_annee')
    def _duree_mois(self):
        for rec in self:
            rec.duree_mois = rec.duree_annee * 12

    name = fields.Char(u'Numéro', required=True, readonly=True, default='New')
    objet = fields.Char(u'Objet du crédit', tracking=True, required=True)
    num_accord = fields.Char('Accord de comité des engagements')
    user_id = fields.Many2one('res.users', string='Responsable', default=lambda self: self.env.user)
    num_enregistrement = fields.Char('Numéro enregistrement')
    date_enregistrement = fields.Date('Date d\'enregistrement')
    date_signature = fields.Date('Date signature', default=fields.Date.today())
    date_notification = fields.Date('Date notification')
    date_limite = fields.Date('Date limite')
    type_credit = fields.Selection([('investissement', 'Investissement'),], string=u'Type crédit', default='investissement')
    partner_id = fields.Many2one('res.partner', string='Client', required=True)
    state = fields.Selection([('active', 'Active'),
                              ('signed', 'Signée'),
                              ('valide', 'Valide'),
                              ('enreg', 'Enregistrée'),
                              ('done', 'Clôturée'),
                              ('archived', u'Archivé'),
                              ('cancel', 'Annulée'),
                              ], string=u'Etat', default='active')

    description = fields.Text('Description')

    # Conditions
    commission_gestion = fields.Float('Commission de gestion')
    commission_engagement = fields.Float('Commission d\'engagement')
    taux_interet = fields.Float('Taut d\'interet')
    montant = fields.Monetary('Montant')
    currency_id = fields.Many2one('res.currency', string='Devise', default=lambda self: self.env.company.currency_id)

    duree_annee = fields.Integer('Durée (année)')
    duree_mois = fields.Integer(compute=_duree_mois, string='Durée (mois)')
    date_limite_utilisation = fields.Date('Date limite d\'utilisation')
    type_duree_differe = fields.Selection([('partiel', 'Partiel'), ('total', 'Total')], string=u'Type durée différé', default='partiel')
    duree_differe = fields.Char('Durée de la période différé ')
    taux_bonification = fields.Float('Taux de Bonification')
    duree_bonification = fields.Char('Durée de Bonification ')

    # avenant
    type_convention = fields.Selection([('convention', 'Convention'), ('avenant', 'Avenant')], string='Type', default='convention')
    num_avenantcn = fields.Char(u'Numéro avenant', readonly=True)
    parent_id = fields.Many2one('convention', string='Convention origine', readonly=True)
    objet_avenant = fields.Char(u'Objet de l\'avenant', tracking=True)
    date = fields.Date('Date')

    # Garanties
    hypotheque = fields.Char('Hypothèque')
    hypotheque_date = fields.Date('Date Hypothèque')
    fichier_piece_jointe_hypotheque = fields.Binary(string='Hypothèque Pièce Jointe')
    hypotheque_piece = fields.Char(string='Nom du Fichier')

    nantissement_action = fields.Char('Nantissement d\'action ')
    nantissement_action_date = fields.Date('Date de nantissement d\'action')
    fichier_piece_jointe_nantissement_action = fields.Binary(string='Nantissement d\'action Pièce Jointe')
    nantissement_action_piece = fields.Char(string='Nom du Fichier')

    nantissement_equipement = fields.Char('Nantissement d\'équipement ')
    nantissement_equipement_date = fields.Date('Date de nantissement d\'équipement')
    fichier_piece_jointe_nantissement_equipement = fields.Binary(string='Nantissement d\'équipement Pièce Jointe')
    nantissement_equipement_piece = fields.Char(string='Nom du Fichier')

    specimen_signature = fields.Char('Spécimen de signature')
    specimen_signature_date = fields.Date('Date de spécimen de signature')
    fichier_piece_jointe_specimen_signature = fields.Binary(string='Specimen de signature Pièce Jointe')
    specimen_signature_piece = fields.Char(string='Nom du Fichier')

    billet_ordre_global = fields.Char('Billet à ordre global')
    billet_ordre_global_date = fields.Date('Date de Billet à ordre global')
    fichier_piece_jointe_billet_ordre_global = fields.Binary(string='Billet à ordre global Pièce Jointe')
    billet_ordre_global_piece = fields.Char(string='Nom du Fichier')

    chaine_billet_ordre = fields.Char('Chaine de billet à ordre après la période d\'utilisation')
    chaine_billet_ordre_date = fields.Date('Date de chaine de billet à ordre après la période d\'utilisation')
    fichier_piece_jointe_chaine_billet_ordre = fields.Binary(string='chaine de billet à ordre global Pièce Jointe')
    chaine_billet_ordre_piece = fields.Char(string='Nom du Fichier')

    caution_solidaire = fields.Char('Caution solidaire')
    caution_solidaire_date = fields.Date('Date de caution solidaire')
    fichier_piece_jointe_caution_solidaire = fields.Binary(string='caution solidaire Pièce Jointe')
    caution_solidaire_piece = fields.Char(string='Nom du Fichier')

    def action_signed(self):
        self.date_signature = fields.Date.today()
        self.state = 'signed'

    def action_validate(self):
        self.state = 'valide'

    def unlink(self):
        if self.state == 'active':
            super(Convention,self).unlink()
        else:
            raise UserError(_('La convention a éte signée , vous ne pouvez pas la supprimer .'))

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].get('itdev.engagement')

        return super(Convention, self).create(vals)

    def create_avenantc(self):
        return {
            'name': _(u'Création avenant'),
            'type': 'ir.actions.act_window',
            'res_model': 'create.avenantc.wizard',
            'view_mode': 'form',
            'view_id': self.env.ref('engagement.create_avenantc_form').id,
            'target': 'new',
            'context': {
                'default_convention_id': self.id,
                'default_date_avenant': fields.Date.today()}
        }

    def action_archiver(self):
        self.state = 'archived'




 #   @api.model
 #   def action_go_to_convention(self):
 #       return {
  #          'nam#e': 'Convention',
   #         'vi"e##w_type': 'form',
    #        '""view_mode': 'form',
     #""#       'res_model': 'convention',
        #   "" #"  'res_id': self.id,
        #     "" 'type': 'ir.actions.act_window',
#   }
# class ConventionCondition(models.Model):
#     _name = 'convention.condition'
#     _inherit     = ['mail.thread', 'mail.activity.mixin']
#     _description = u'Condition d\'une convention'
#
#     name = fields.Char(u'Numéro', required=True, readonly=True, default='New')
